package org.Android_Project_Study.todo;

public class Menu {
    String taskName, taskTimeStamp;

    public Menu (){

    }
    public Menu (String taskName, String taskTimeStamp){
        this.taskName = taskName;
        this.taskTimeStamp = taskTimeStamp;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskTimeStamp(String taskTimeStamp) {
        this.taskTimeStamp = taskTimeStamp;
    }

    public String getTaskTimeStamp() {
        return taskTimeStamp;
    }
}
