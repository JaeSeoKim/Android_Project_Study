package org.Android_Project_Study.todo;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.InputFilter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    DbHelper dbHelper;
    //Dbhelper 객체 생성
    MenuAdapter madapter;
    //ListVIew와 ListArray를 연결하기 위한 어댑터 선언
    ListView lstTask;
    //ListView, lstTaskTime 선언

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DbHelper(this);
        //dbHelper 를 초기화
        lstTask = (ListView)findViewById(R.id.lstTask);
        //lstTask 를 layout 하고 연결
        loadDataList();
        //함수 실행
    }


    private void loadDataList(){
        ArrayList nameList = dbHelper.getDataList(DbHelper.DB_COLUMN_NAME);
        ArrayList timeList = dbHelper.getDataList(DbHelper.DB_COLUMN_TIME_STAMP);
        //데이터를 저장하기 위한 ArrayList 선언 후 dbHelper의 getTaskList()함수를 이용하여 데이터를 저장시킴
        if(madapter==null){
            //만약 mAdapter가 null값 이라면 (초기화가 안되어 있다면)
            madapter = new MenuAdapter(this);
            //row.xml(layout)의 task_title 에 taskList(정보)를 설정
            lstTask.setAdapter(madapter);
            //ListView에 어댑터를 연결!
        }
        //만약 mAdapter가 초기화가 되어 있고 데이터를 가지고 있다면
        madapter.clear();
        //어뎁터를 클리어
        madapter.addAll(nameList,timeList);
        //어뎁터에 taskList(정보)를 추가
        madapter.notifyDataSetChanged();
        //변경된 데이터를 전달
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //옵션 매뉴에 대해 생성이 되면 작동
        getMenuInflater().inflate(R.menu.menu,menu);
        //메뉴를 생성
        Drawable icon = menu.getItem(0).getIcon();
        //icon를 설정
        icon.mutate();
        //icon에 대해 돌연변이 즉 수정을 위한 선언
        icon.setColorFilter(ContextCompat.getColor(this, R.color.colorPastelBlack), PorterDuff.Mode.SRC_IN);
        //icon의 컬러 설정
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //옵션 메뉴에 대해 아이템이 선택되면 작동하는 함수 ( 오버라이딩으로 사용자가 정의하여 사용)
        switch (item.getItemId()){
            //Switch문을 이용하여 아이템 id에 대하여 작동하도록 함
            case R.id.action_add_task:
                //ADD 버튼이 눌렸을떄에 대한 처리
                LayoutInflater inflater = (LayoutInflater) getApplicationContext().getSystemService(LAYOUT_INFLATER_SERVICE);
                View addTask = inflater.inflate(R.layout.add_task,null);
                AlertDialog.Builder adialog = new AlertDialog.Builder(this);

                final EditText etTaskName = (EditText) addTask.findViewById(R.id.etTaskName);
                final EditText etTaskDesc = (EditText) addTask.findViewById(R.id.etTaskDesc);
                //EditText 객체를 생성하고 초기화

                adialog.setTitle("New ToDo!");
                adialog.setView(addTask);
                adialog.setPositiveButton("Add", new DialogInterface.OnClickListener() {
                    //긍정 버튼를 생성하고 액션 리스너를 추가
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String name = String.valueOf(etTaskName.getText());
                        String desc = String.valueOf(etTaskDesc.getText());
                        //EditText의 값을 가져와 task에 저장
                        dbHelper.insertData(name,desc);
                        //dbHelper를 이용하여 task를 Insert
                        loadDataList();
                        //화면에 있는 ListView를 불러옴
                    }
                });
                adialog.setNegativeButton("Cancel",null);
                //부정에 대한 버튼을 추가하고 액션에 대해서 아무 처리를 안함
                adialog.create();
                //AlertDialog 를 이용하여 입력 값을 받고 작동을 하도록 함
                adialog.show();
                return true;
        }
        return super.onOptionsItemSelected(item);
        //부모에게 선택된 아이템을 리턴
    }

    public void deleteTask(View view){
        //To Do Task를 지우기 위한 함수
        View parent = (View)view.getParent();
        //View parent 객체 생성 view 의 부모를 가져와 초기화
        TextView taskTextView = (TextView) parent.findViewById(R.id.task_title);
        //TextView 객체를 생성하고 이때 부모의 View에서 task_title를 가져옴
        Log.e("String", (String) taskTextView.getText());
        //삭제처리에 대해 로그를 저장
        String task = String.valueOf(taskTextView.getText());
        //text를 뽑아서 task에 저장
        dbHelper.deleteTask(task);
        //dbHelper를 이용하여 db에서 제거
        loadDataList();
        //ListView 재로딩!
    }

    public void openDescription(View view){

    }

}
