package org.Android_Project_Study.todo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class MenuAdapter extends BaseAdapter {

    private ArrayList<Menu> listViewItemList = null;
    private LayoutInflater mInflater = null;

    public MenuAdapter(Context context) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        listViewItemList = new ArrayList<Menu>();

    }


    @Override
    public int getCount() {
        return listViewItemList.size();
    }

    @Override
    public Object getItem(int position) {
        return listViewItemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null) {

            convertView = mInflater.inflate(R.layout.row, parent, false);

        }

        TextView tvTaskName = (TextView) convertView.findViewById(R.id.task_title);

        TextView tvTaskTimeStamp = (TextView) convertView.findViewById(R.id.task_time_stamp);

        Menu menu= listViewItemList.get(position);

        tvTaskName.setText(menu.getTaskName());

        tvTaskTimeStamp.setText(menu.getTaskTimeStamp());

        return convertView;
    }

    public void clear() {
        listViewItemList.clear();
    }

    public void addAll(ArrayList<String> taskName,ArrayList<String> taskTimeStamp) {
        for (int i = 0; i < taskName.size(); i++){
            addItem(taskName.get(i),taskTimeStamp.get(i));
        }
    }

    public void addItem(String name, String timeStamp) {
        Menu item = new Menu();
        item.setTaskName(name);
        item.setTaskTimeStamp(timeStamp);
        listViewItemList.add(item);
    }
}
