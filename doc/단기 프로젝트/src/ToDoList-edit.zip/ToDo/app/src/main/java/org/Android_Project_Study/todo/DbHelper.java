package org.Android_Project_Study.todo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
/*
SQLite DB 관련 Class
*/

public class DbHelper extends SQLiteOpenHelper {
//SQLiteOpenHelper를 상속 받는다.

    private static final String DB_NAME="EDMTDev";
    private static final int DB_VER = 1;
    public static final String DB_TABLE="Task";
    public static final String DB_COLUMN_NAME = "TaskName";
    //상수로 DB에 관련된 정보를 선언한다.
    public static final String DB_COLUMN_DESCRIPTHION = "TaskDescription";
    public static final String DB_COLUMN_TIME_STAMP = "TaskTimeStap";
    //추가된 DB 항목 -- ver2

    public DbHelper(Context context) {
        super(context, DB_NAME, null, DB_VER);
    }
    //Constructor 생성자 부분! 어플에 대한 context 와 DB_NAME, DB_VER 와 같은 정보를 넘겨준다.

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = String.format(
                "CREATE TABLE %s (ID INTEGER PRIMARY KEY AUTOINCREMENT,%s TEXT NOT NULL,%s TEXT,%s DATETIME DEFAULT (datetime('now','localtime')));",
                DB_TABLE,DB_COLUMN_NAME,DB_COLUMN_DESCRIPTHION,DB_COLUMN_TIME_STAMP);
        db.execSQL(query);
        /*DB에 새로 Description과 timestamp를 추가*/
    }
    //DB가 만들어지면 TABLE 과 Column 에 대해서 정의

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query = String.format("DELETE TABLE IF EXISTS %s",DB_TABLE);
        db.execSQL(query);
        onCreate(db);

    }
    //새로운 버전의 DB가 생성 되었을 때 예전 버전의 DB 초기화

    /*여기서 부터 사용자 정의 함수*/
//    public void insertNewTask(String task){
//        //할일(task)에 대해 인자로 넘겨 받음
//        SQLiteDatabase db= this.getWritableDatabase();
//        //SQLite 객채 생성 (쓰기 권한)
//        ContentValues values = new ContentValues();
//        //ContentValues 객체 생성
//        values.put(DB_COLUMN_NAME,task);
//        //values에 컬럼과 task에 대해 값을 넣음
//        db.insertWithOnConflict(DB_TABLE,null,values,SQLiteDatabase.CONFLICT_REPLACE);
//        //db를 이용하여 task값을 삽잎
//        db.close();
//        //db 객체 닫음
//    }

    public void insertData(String name,String desc){
        //할일(task)에 대해 인자로 넘겨 받음
        SQLiteDatabase db= this.getWritableDatabase();
        //SQLite 객채 생성 (쓰기 권한)
        ContentValues values = new ContentValues();
        //ContentValues 객체 생성
        values.put(DB_COLUMN_NAME,name);
        values.put(DB_COLUMN_DESCRIPTHION,desc);
        //values에 컬럼과 task에 대해 값을 넣음
        db.insertWithOnConflict(DB_TABLE,null,values,SQLiteDatabase.CONFLICT_REPLACE);
        //db를 이용하여 task값을 삽잎
        Log.e("DB Insert", name+":"+desc);
        db.close();
        //db 객체 닫음
    }


    public void deleteTask(String task){
        //할일(task)에 대해 인자로 넘겨 받음
        SQLiteDatabase db = this.getWritableDatabase();
        //SQLite 객채 생성 (쓰기 권한)
        db.delete(DB_TABLE,DB_COLUMN_NAME + " = ?",new String[]{task});
        //db를 이용하여 task 제거
        db.close();
        //db 객체 닫음
    }


    public ArrayList<String> getDataList(String DB_COLUMN){
        ArrayList<String> dataList = new ArrayList<>();
        //tasks 를 저장할 배열 생성
        SQLiteDatabase db = this.getReadableDatabase();
        //SQLite 객채 생성 (읽기 권한)
        Cursor cursor = db.query(DB_TABLE,new String[]{DB_COLUMN},null,null,null,null,null);
        //cursor 에 인자값으로 넘어온 컬럼명의 데이터에 해당하는 위치값을 저장
        while(cursor.moveToNext()){
            //cursor 값이 존재 할동안 반복
            int index = cursor.getColumnIndex(DB_COLUMN);
            //index를 하나씩 받아옴
            dataList.add(cursor.getString(index));
            //index를 이용하여 String 값을 받아 dataList에 추가
        }

        cursor.close();
        //cursor 객체 닫음
        db.close();
        //db 객체 닫음
        return dataList;
        //구해진 dataList 반환!
    }
}
